import { DashboardHeader } from "@/components/dashboard-header"
import { MarketOverview } from "@/components/market-overview"
import { TrendingCoins } from "@/components/trending-coins"
import { PortfolioSummary } from "@/components/portfolio-summary"
import { MarketNews } from "@/components/market-news"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <div className="col-span-full">
            <MarketOverview />
          </div>
          <div className="md:col-span-2">
            <TrendingCoins />
          </div>
          <div>
            <PortfolioSummary />
          </div>
          <div className="col-span-full">
            <MarketNews />
          </div>
        </div>
      </main>
    </div>
  )
}

