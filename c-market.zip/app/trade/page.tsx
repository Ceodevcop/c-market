import { DashboardHeader } from "@/components/dashboard-header"
import { TradingInterface } from "@/components/trading-interface"

export default function TradePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <main className="flex-1 container mx-auto px-4 py-6">
        <TradingInterface />
      </main>
    </div>
  )
}

