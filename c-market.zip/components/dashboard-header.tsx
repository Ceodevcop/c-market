"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Bell, Menu, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { ThemeToggle } from "@/components/theme-toggle"

export function DashboardHeader() {
  const pathname = usePathname()

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2 md:gap-4">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="pr-0">
              <MobileNav pathname={pathname} />
            </SheetContent>
          </Sheet>
          <Link href="/" className="flex items-center gap-2">
            <span className="font-bold text-xl">C-Market</span>
          </Link>
          <div className="hidden md:flex">
            <DesktopNav pathname={pathname} />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden md:flex md:w-64 lg:w-80">
            <div className="relative w-full">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search coins..." className="w-full pl-8" />
            </div>
          </div>
          <Button variant="outline" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-primary"></span>
            <span className="sr-only">Notifications</span>
          </Button>
          <ThemeToggle />
          <Button>Connect Wallet</Button>
        </div>
      </div>
    </header>
  )
}

function DesktopNav({ pathname }: { pathname: string }) {
  return (
    <nav className="flex items-center gap-6 text-sm">
      <Link
        href="/"
        className={`transition-colors hover:text-foreground/80 ${
          pathname === "/" ? "text-foreground font-medium" : "text-foreground/60"
        }`}
      >
        Dashboard
      </Link>
      <Link
        href="/markets"
        className={`transition-colors hover:text-foreground/80 ${
          pathname === "/markets" ? "text-foreground font-medium" : "text-foreground/60"
        }`}
      >
        Markets
      </Link>
      <Link
        href="/trade"
        className={`transition-colors hover:text-foreground/80 ${
          pathname === "/trade" ? "text-foreground font-medium" : "text-foreground/60"
        }`}
      >
        Trade
      </Link>
      <Link
        href="/portfolio"
        className={`transition-colors hover:text-foreground/80 ${
          pathname === "/portfolio" ? "text-foreground font-medium" : "text-foreground/60"
        }`}
      >
        Portfolio
      </Link>
    </nav>
  )
}

function MobileNav({ pathname }: { pathname: string }) {
  return (
    <nav className="grid gap-2 py-6">
      <Link
        href="/"
        className={`flex items-center gap-2 px-3 py-2 text-sm ${
          pathname === "/"
            ? "bg-accent text-accent-foreground font-medium"
            : "hover:bg-accent hover:text-accent-foreground"
        } rounded-md transition-colors`}
      >
        Dashboard
      </Link>
      <Link
        href="/markets"
        className={`flex items-center gap-2 px-3 py-2 text-sm ${
          pathname === "/markets"
            ? "bg-accent text-accent-foreground font-medium"
            : "hover:bg-accent hover:text-accent-foreground"
        } rounded-md transition-colors`}
      >
        Markets
      </Link>
      <Link
        href="/trade"
        className={`flex items-center gap-2 px-3 py-2 text-sm ${
          pathname === "/trade"
            ? "bg-accent text-accent-foreground font-medium"
            : "hover:bg-accent hover:text-accent-foreground"
        } rounded-md transition-colors`}
      >
        Trade
      </Link>
      <Link
        href="/portfolio"
        className={`flex items-center gap-2 px-3 py-2 text-sm ${
          pathname === "/portfolio"
            ? "bg-accent text-accent-foreground font-medium"
            : "hover:bg-accent hover:text-accent-foreground"
        } rounded-md transition-colors`}
      >
        Portfolio
      </Link>
    </nav>
  )
}

