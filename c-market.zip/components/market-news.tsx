import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const newsItems = [
  {
    id: 1,
    title: "Bitcoin Surpasses $56,000 as Institutional Adoption Continues",
    source: "CryptoNews",
    time: "2 hours ago",
    snippet:
      "Bitcoin has surged past $56,000 as major financial institutions announce new cryptocurrency investment products.",
  },
  {
    id: 2,
    title: "Ethereum Upgrade Set to Improve Network Scalability",
    source: "BlockchainToday",
    time: "5 hours ago",
    snippet:
      "The upcoming Ethereum network upgrade promises to address scalability issues and reduce gas fees for users.",
  },
  {
    id: 3,
    title: "Regulatory Clarity Emerges for Cryptocurrency Markets",
    source: "FinanceDaily",
    time: "8 hours ago",
    snippet: "New regulatory frameworks are providing clearer guidelines for cryptocurrency businesses and investors.",
  },
  {
    id: 4,
    title: "DeFi Projects See Surge in Total Value Locked",
    source: "DeFiInsider",
    time: "12 hours ago",
    snippet:
      "Decentralized finance protocols are experiencing significant growth with total value locked reaching new highs.",
  },
]

export function MarketNews() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Market News</CardTitle>
        <CardDescription>Latest cryptocurrency and blockchain news</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2">
          {newsItems.map((item) => (
            <Card key={item.id} className="overflow-hidden">
              <div className="p-4">
                <h3 className="font-semibold text-lg">{item.title}</h3>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                  <span>{item.source}</span>
                  <span>•</span>
                  <span>{item.time}</span>
                </div>
                <p className="mt-2 text-sm">{item.snippet}</p>
              </div>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

