"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const marketData = [
  { date: "Jan", btc: 42000, eth: 3200, total: 2.1 },
  { date: "Feb", btc: 44500, eth: 3100, total: 2.4 },
  { date: "Mar", btc: 47000, eth: 3300, total: 2.7 },
  { date: "Apr", btc: 51000, eth: 3500, total: 3.0 },
  { date: "May", btc: 49000, eth: 3400, total: 2.9 },
  { date: "Jun", btc: 53000, eth: 3600, total: 3.2 },
  { date: "Jul", btc: 56000, eth: 3800, total: 3.5 },
]

export function MarketOverview() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Market Overview</CardTitle>
        <CardDescription>Global cryptocurrency market cap and volume</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="market-cap">
          <TabsList className="mb-4">
            <TabsTrigger value="market-cap">Market Cap</TabsTrigger>
            <TabsTrigger value="volume">Volume</TabsTrigger>
            <TabsTrigger value="dominance">Dominance</TabsTrigger>
          </TabsList>
          <TabsContent value="market-cap" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <div className="text-sm font-medium">Total Market Cap</div>
                <div className="text-2xl font-bold">$2.34T</div>
                <div className="text-sm text-green-500">+5.6% (24h)</div>
              </div>
              <div>
                <div className="text-sm font-medium">BTC Market Cap</div>
                <div className="text-2xl font-bold">$1.08T</div>
                <div className="text-sm text-green-500">+3.2% (24h)</div>
              </div>
              <div>
                <div className="text-sm font-medium">ETH Market Cap</div>
                <div className="text-2xl font-bold">$420B</div>
                <div className="text-sm text-green-500">+4.1% (24h)</div>
              </div>
            </div>
            <div className="h-[300px] mt-6">
              <ChartContainer
                config={{
                  total: {
                    label: "Total Market Cap (Trillion USD)",
                    color: "hsl(var(--chart-1))",
                  },
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={marketData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Line type="monotone" dataKey="total" stroke="var(--color-total)" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </TabsContent>
          <TabsContent value="volume" className="h-[400px]">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <div className="text-sm font-medium">24h Volume</div>
                <div className="text-2xl font-bold">$98.7B</div>
                <div className="text-sm text-red-500">-2.3% (24h)</div>
              </div>
              <div>
                <div className="text-sm font-medium">BTC Volume</div>
                <div className="text-2xl font-bold">$42.3B</div>
                <div className="text-sm text-red-500">-1.8% (24h)</div>
              </div>
              <div>
                <div className="text-sm font-medium">ETH Volume</div>
                <div className="text-2xl font-bold">$18.5B</div>
                <div className="text-sm text-green-500">+0.7% (24h)</div>
              </div>
            </div>
            <div className="h-[300px]">
              <ChartContainer
                config={{
                  btc: {
                    label: "Bitcoin (USD)",
                    color: "hsl(var(--chart-1))",
                  },
                  eth: {
                    label: "Ethereum (USD)",
                    color: "hsl(var(--chart-2))",
                  },
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={marketData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Line type="monotone" dataKey="btc" stroke="var(--color-btc)" strokeWidth={2} />
                    <Line type="monotone" dataKey="eth" stroke="var(--color-eth)" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </TabsContent>
          <TabsContent value="dominance">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <div className="text-sm font-medium">BTC Dominance</div>
                <div className="text-2xl font-bold">46.2%</div>
                <div className="text-sm text-red-500">-0.3% (24h)</div>
              </div>
              <div>
                <div className="text-sm font-medium">ETH Dominance</div>
                <div className="text-2xl font-bold">18.7%</div>
                <div className="text-sm text-green-500">+0.2% (24h)</div>
              </div>
              <div>
                <div className="text-sm font-medium">Stablecoin Dominance</div>
                <div className="text-2xl font-bold">8.3%</div>
                <div className="text-sm text-red-500">-0.1% (24h)</div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

