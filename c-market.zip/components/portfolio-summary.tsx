"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts"
import { ChartContainer } from "@/components/ui/chart"

const portfolioData = [
  { name: "Bitcoin", value: 45, color: "hsl(var(--chart-1))" },
  { name: "Ethereum", value: 30, color: "hsl(var(--chart-2))" },
  { name: "Solana", value: 15, color: "hsl(var(--chart-3))" },
  { name: "Others", value: 10, color: "hsl(var(--chart-4))" },
]

export function PortfolioSummary() {
  const totalValue = 24650.75
  const dailyChange = 876.32
  const dailyChangePercent = 3.68

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Portfolio Summary</CardTitle>
        <CardDescription>Your cryptocurrency holdings</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <div className="text-sm font-medium text-muted-foreground">Total Value</div>
            <div className="text-2xl font-bold">
              ${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-sm text-green-500">
              +${dailyChange.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (
              {dailyChangePercent}%) Today
            </div>
          </div>
          <div className="h-[200px]">
            <ChartContainer
              config={{
                bitcoin: {
                  label: "Bitcoin",
                  color: "hsl(var(--chart-1))",
                },
                ethereum: {
                  label: "Ethereum",
                  color: "hsl(var(--chart-2))",
                },
                solana: {
                  label: "Solana",
                  color: "hsl(var(--chart-3))",
                },
                others: {
                  label: "Others",
                  color: "hsl(var(--chart-4))",
                },
              }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={portfolioData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {portfolioData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

