"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const chartData = [
  { time: "9:00", price: 56200 },
  { time: "10:00", price: 56400 },
  { time: "11:00", price: 56100 },
  { time: "12:00", price: 56300 },
  { time: "13:00", price: 56500 },
  { time: "14:00", price: 56700 },
  { time: "15:00", price: 56600 },
  { time: "16:00", price: 56800 },
  { time: "17:00", price: 57000 },
]

export function TradingInterface() {
  const [amount, setAmount] = useState(0.1)
  const [orderType, setOrderType] = useState("market")
  const [timeframe, setTimeframe] = useState("1d")

  const currentPrice = 56432.21
  const totalValue = amount * currentPrice

  return (
    <div className="grid gap-6 md:grid-cols-3">
      <div className="md:col-span-2">
        <Card className="h-full">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>BTC/USD</CardTitle>
                <CardDescription>Bitcoin to US Dollar</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Select defaultValue="1d" onValueChange={setTimeframe}>
                  <SelectTrigger className="w-[100px]">
                    <SelectValue placeholder="Timeframe" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1h">1H</SelectItem>
                    <SelectItem value="4h">4H</SelectItem>
                    <SelectItem value="1d">1D</SelectItem>
                    <SelectItem value="1w">1W</SelectItem>
                    <SelectItem value="1m">1M</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[400px]">
              <ChartContainer
                config={{
                  price: {
                    label: "Price (USD)",
                    color: "hsl(var(--chart-1))",
                  },
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis domain={["auto", "auto"]} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Line type="monotone" dataKey="price" stroke="var(--color-price)" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
            <div className="mt-4 grid grid-cols-4 gap-4">
              <div>
                <div className="text-sm font-medium text-muted-foreground">Price</div>
                <div className="text-lg font-bold">${currentPrice.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-sm font-medium text-muted-foreground">24h Change</div>
                <div className="text-lg font-bold text-green-500">+3.45%</div>
              </div>
              <div>
                <div className="text-sm font-medium text-muted-foreground">24h High</div>
                <div className="text-lg font-bold">
                  ${(currentPrice * 1.05).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </div>
              </div>
              <div>
                <div className="text-sm font-medium text-muted-foreground">24h Low</div>
                <div className="text-lg font-bold">
                  ${(currentPrice * 0.97).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      <div>
        <Card className="h-full">
          <CardHeader>
            <CardTitle>Trade</CardTitle>
            <CardDescription>Buy or sell Bitcoin</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="buy">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="buy">Buy</TabsTrigger>
                <TabsTrigger value="sell">Sell</TabsTrigger>
              </TabsList>
              <TabsContent value="buy" className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="order-type">Order Type</Label>
                  <Select defaultValue="market" onValueChange={setOrderType}>
                    <SelectTrigger id="order-type">
                      <SelectValue placeholder="Order Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="market">Market</SelectItem>
                      <SelectItem value="limit">Limit</SelectItem>
                      <SelectItem value="stop">Stop</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {orderType === "limit" && (
                  <div className="space-y-2">
                    <Label htmlFor="limit-price">Limit Price</Label>
                    <Input id="limit-price" type="number" placeholder="Enter price" defaultValue={currentPrice} />
                  </div>
                )}

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="amount">Amount (BTC)</Label>
                    <span className="text-sm text-muted-foreground">Balance: 0.5 BTC</span>
                  </div>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(Number.parseFloat(e.target.value) || 0)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Amount Slider</Label>
                  <Slider
                    defaultValue={[10]}
                    max={100}
                    step={1}
                    value={[(amount * 100) / 0.5]}
                    onValueChange={(value) => setAmount((value[0] * 0.5) / 100)}
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>0%</span>
                    <span>25%</span>
                    <span>50%</span>
                    <span>75%</span>
                    <span>100%</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Total</Label>
                  <div className="text-lg font-bold">
                    ${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>

                <Button className="w-full">Buy Bitcoin</Button>
              </TabsContent>
              <TabsContent value="sell" className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="order-type-sell">Order Type</Label>
                  <Select defaultValue="market">
                    <SelectTrigger id="order-type-sell">
                      <SelectValue placeholder="Order Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="market">Market</SelectItem>
                      <SelectItem value="limit">Limit</SelectItem>
                      <SelectItem value="stop">Stop</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="amount-sell">Amount (BTC)</Label>
                    <span className="text-sm text-muted-foreground">Balance: 0.5 BTC</span>
                  </div>
                  <Input id="amount-sell" type="number" placeholder="0.00" defaultValue="0.1" />
                </div>

                <div className="space-y-2">
                  <Label>Amount Slider</Label>
                  <Slider defaultValue={[20]} max={100} step={1} />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>0%</span>
                    <span>25%</span>
                    <span>50%</span>
                    <span>75%</span>
                    <span>100%</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Total</Label>
                  <div className="text-lg font-bold">$5,643.22</div>
                </div>

                <Button className="w-full" variant="destructive">
                  Sell Bitcoin
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

