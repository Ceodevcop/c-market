"use client"

import { useState } from "react"
import { ArrowDown, ArrowUp, Search } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

const trendingCoins = [
  {
    id: "bitcoin",
    name: "Bitcoin",
    symbol: "BTC",
    price: 56432.21,
    change24h: 3.45,
    marketCap: 1080000000000,
    volume24h: 42300000000,
  },
  {
    id: "ethereum",
    name: "Ethereum",
    symbol: "ETH",
    price: 3821.67,
    change24h: 4.12,
    marketCap: 420000000000,
    volume24h: 18500000000,
  },
  {
    id: "binancecoin",
    name: "Binance Coin",
    symbol: "BNB",
    price: 612.43,
    change24h: -1.23,
    marketCap: 94000000000,
    volume24h: 2100000000,
  },
  {
    id: "solana",
    name: "Solana",
    symbol: "SOL",
    price: 142.87,
    change24h: 7.65,
    marketCap: 58000000000,
    volume24h: 3700000000,
  },
  {
    id: "cardano",
    name: "Cardano",
    symbol: "ADA",
    price: 1.23,
    change24h: -2.34,
    marketCap: 39000000000,
    volume24h: 1200000000,
  },
  {
    id: "polkadot",
    name: "Polkadot",
    symbol: "DOT",
    price: 21.56,
    change24h: 1.87,
    marketCap: 25000000000,
    volume24h: 980000000,
  },
  {
    id: "dogecoin",
    name: "Dogecoin",
    symbol: "DOGE",
    price: 0.12,
    change24h: 5.43,
    marketCap: 16000000000,
    volume24h: 1500000000,
  },
]

export function TrendingCoins() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredCoins = trendingCoins.filter(
    (coin) =>
      coin.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      coin.symbol.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Trending Coins</CardTitle>
            <CardDescription>Top cryptocurrencies by market cap</CardDescription>
          </div>
          <div className="relative w-full max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search coins..."
              className="w-full pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead className="text-right">Price</TableHead>
              <TableHead className="text-right">24h Change</TableHead>
              <TableHead className="text-right hidden md:table-cell">Market Cap</TableHead>
              <TableHead className="text-right hidden md:table-cell">Volume (24h)</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredCoins.map((coin) => (
              <TableRow key={coin.id}>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                      {coin.symbol.charAt(0)}
                    </div>
                    <div>
                      <div className="font-medium">{coin.name}</div>
                      <div className="text-xs text-muted-foreground">{coin.symbol}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-right font-medium">
                  ${coin.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </TableCell>
                <TableCell className="text-right">
                  <Badge variant={coin.change24h >= 0 ? "outline" : "destructive"} className="gap-1">
                    {coin.change24h >= 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                    {Math.abs(coin.change24h).toFixed(2)}%
                  </Badge>
                </TableCell>
                <TableCell className="text-right hidden md:table-cell">
                  ${(coin.marketCap / 1000000000).toFixed(1)}B
                </TableCell>
                <TableCell className="text-right hidden md:table-cell">
                  ${(coin.volume24h / 1000000000).toFixed(1)}B
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

